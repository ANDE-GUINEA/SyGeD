<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-full overflow-auto bg-gray-100 rounded shadow-lg dark:bg-gray-900 fi-descript">
        <div x-data="{ open: true }" class="px-6 py-4 mb-2">
            <span x-on:click="open = ! open" class="mb-2 text-xl font-bold cursor-pointer text-primary-400">
                DECRET: <?php echo $record->code; ?>/<?php echo $record->init; ?>/<?php echo $record->objet; ?>


            </span>
            <div x-show="open" x-transition>

                <p class="text-base text-gray-700 dark:text-white">
                    <?php echo $record->content; ?>

                </p>
            </div>
        </div>

        <div class="block">
            <?php echo $__env->make('components.signes.document-signe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.publiers.publier', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- __BLOCK__ --><?php if($record->archives): ?>
        <?php echo $__env->make('components.archives.archive', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?> <!-- __ENDBLOCK__ -->
            <?php echo $__env->make('components.soumis.document-soumis', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <h1 class="text-xl font-extrabold text-gray-900 uppercase dark:text-white">
        Parcours du decret
    </h1>
    <?php echo $__env->make('components.timeline', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\SyGeD\resources\views/filament/resources/decret-resource/pages/show-decret.blade.php ENDPATH**/ ?>