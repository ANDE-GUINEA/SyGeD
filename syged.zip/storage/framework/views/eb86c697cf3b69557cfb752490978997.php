<img src="<?php echo e(asset('storage/logo/gn.png')); ?>" alt="Logo" class="h-10">
<?php /**PATH C:\laragon\www\SyGeD\resources\views/vendor/filament-panels/components/logo.blade.php ENDPATH**/ ?>