<?php
    $name = uniqid();
?>
<?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => $getFieldWrapperView()] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\DynamicComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => $field]); ?>
    <div
        wire:ignore
    >
    <div class="bg-[#ebf4f8]"></div>
    <div
        x-ref="container"
        x-data="dateRangeComponent({
                state:  <?php if ((object) ($getStatePath()) instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e($getStatePath()->value()); ?>')<?php echo e($getStatePath()->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e($getStatePath()); ?>')<?php endif; ?>,
                name: <?php echo \Illuminate\Support\Js::from($name)->toHtml() ?>,
                alwaysShowCalendars: <?php echo \Illuminate\Support\Js::from($isAlwaysShowCalender())->toHtml() ?>,
                autoApply: <?php echo \Illuminate\Support\Js::from($getAutoApplyOption())->toHtml() ?>,
                linkedCalendars: <?php echo \Illuminate\Support\Js::from($getLinkedCalendarsOption())->toHtml() ?>,
                autoUpdateInput: false,
                startDate: <?php echo \Illuminate\Support\Js::from($getStartDate())->toHtml() ?>,
                endDate: <?php echo \Illuminate\Support\Js::from($getEndDate())->toHtml() ?>,
                maxDate: <?php echo \Illuminate\Support\Js::from($getMaxDate())->toHtml() ?>,
                minDate: <?php echo \Illuminate\Support\Js::from($getMinDate())->toHtml() ?>,
                timePicker: <?php echo \Illuminate\Support\Js::from($getTimePickerOption())->toHtml() ?>,
                timePickerIncrement: <?php echo \Illuminate\Support\Js::from($getTimePickerIncrementOption())->toHtml() ?>,
                displayFormat: <?php echo \Illuminate\Support\Js::from($getDisplayFormat())->toHtml() ?>,
                applyLabel: '<?php echo __('filament-daterangepicker-filter::message.apply'); ?>',
                cancelLabel: '<?php echo __('filament-daterangepicker-filter::message.cancel'); ?>',
                fromLabel: '<?php echo __('filament-daterangepicker-filter::message.from'); ?>',
                toLabel: '<?php echo __('filament-daterangepicker-filter::message.to'); ?>',
                customRangeLabel: '<?php echo __('filament-daterangepicker-filter::message.custom'); ?>',
                january :   '<?php echo __('filament-daterangepicker-filter::message.january'); ?>',
                february :  '<?php echo __('filament-daterangepicker-filter::message.february'); ?>',
                march:      '<?php echo __('filament-daterangepicker-filter::message.march'); ?>',
                april:      '<?php echo __('filament-daterangepicker-filter::message.april'); ?>',
                may:        '<?php echo __('filament-daterangepicker-filter::message.may'); ?>',
                june:       '<?php echo __('filament-daterangepicker-filter::message.june'); ?>',
                july:       '<?php echo __('filament-daterangepicker-filter::message.july'); ?>',
                august:     '<?php echo __('filament-daterangepicker-filter::message.august'); ?>',
                september:  '<?php echo __('filament-daterangepicker-filter::message.september'); ?>',
                october:    '<?php echo __('filament-daterangepicker-filter::message.october'); ?>',
                november :  '<?php echo __('filament-daterangepicker-filter::message.november'); ?>',
                december:   '<?php echo __('filament-daterangepicker-filter::message.december'); ?>',
                sunday:     '<?php echo __('filament-daterangepicker-filter::message.su'); ?>',
                monday:     '<?php echo __('filament-daterangepicker-filter::message.mo'); ?>',
                tuesday:    '<?php echo __('filament-daterangepicker-filter::message.tu'); ?>',
                wednesday:  '<?php echo __('filament-daterangepicker-filter::message.we'); ?>',
                thursday:   '<?php echo __('filament-daterangepicker-filter::message.th'); ?>',
                friday:     '<?php echo __('filament-daterangepicker-filter::message.fr'); ?>',
                saturday:   '<?php echo __('filament-daterangepicker-filter::message.sa'); ?>',
                firstDay:   <?php echo \Illuminate\Support\Js::from($getFirstDayOfWeek())->toHtml() ?>,
                today:      '<?php echo __('filament-daterangepicker-filter::message.today'); ?>',
                yesterday:  '<?php echo __('filament-daterangepicker-filter::message.yesterday'); ?>',
                last_7_days:'<?php echo __('filament-daterangepicker-filter::message.last_7_days'); ?>',
                last_30_days:'<?php echo __('filament-daterangepicker-filter::message.last_30_days'); ?>',
                this_month: '<?php echo __('filament-daterangepicker-filter::message.this_month'); ?>',
                last_month: '<?php echo __('filament-daterangepicker-filter::message.last_month'); ?>',
                this_year:  '<?php echo __('filament-daterangepicker-filter::message.this_year'); ?>',
                last_year:  '<?php echo __('filament-daterangepicker-filter::message.last_year'); ?>',
                handleValueChangeUsing: ( value , name ) => {
                    if(name == '<?php echo e($name); ?>'){
                        window.Livewire.find('<?php echo e($_instance->getId()); ?>').set('<?php echo $getStatePath(); ?>',value);
                    }
                },
            })"

        id="date-range-picker-<?php echo e($name); ?>"
        wire:key="date-range-picker-<?php echo e($name); ?>"
        x-on:keydown.esc="isOpen() && $event.stopPropagation()"
        <?php echo e($attributes->merge($getExtraAttributes())->class(['filament-forms-date-time-picker-component relative'])); ?>

        <?php echo e($getExtraAlpineAttributeBag()); ?>

    >
        <div class="flex flex-row">
            <button
                x-ref="button"
                aria-label="<?php echo e($getPlaceholder()); ?>"
                dusk="filament.forms.<?php echo e($getStatePath()); ?>.open"
                type="button"
                tabindex="-1"
                <?php if($isDisabled()): ?> disabled <?php endif; ?>
                <?php echo e($getExtraTriggerAttributeBag()->class([
                    'bg-white dark:bg-white/5 relative w-full border py-2 pl-3 rtl:pr-3 text-start cursor-default rounded-lg shadow-sm outline-none',
                    'focus-within:ring-1 focus-within:border-primary-500 focus-within:ring-inset focus-within:ring-primary-500' => ! $isDisabled(),
                    'dark:bg-gray-700' => config('forms.dark_mode'),
                    'border-gray-300' => ! $errors->has($getStatePath()),
                    'dark:border-gray-600' => (! $errors->has($getStatePath())) && config('forms.dark_mode'),
                    'border-danger-600' => $errors->has($getStatePath()),
                    'dark:border-danger-400' => $errors->has($getStatePath()) && config('forms.dark_mode'),
                    'opacity-70' => $isDisabled(),
                    'dark:text-gray-300' => $isDisabled() && config('forms.dark_mode'),
                ])); ?>

            >
                <div class="relative inline-block w-full px-2"  id="<?php echo e($name); ?>.container" wire:key="<?php echo e($name); ?>.container">
                    <input
                        readonly
                        x-ref="daterange"
                        name="<?php echo e($name); ?>"
                        placeholder="<?php echo e($getPlaceholder()); ?>"
                        wire:key="<?php echo e($this->id()); ?>.<?php echo e($getStatePath()); ?>.<?php echo e($field::class); ?>.display-text"
                        <?php echo ($id = $getId()) ? "id=\"{$id}\"" : null; ?>

                        class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'w-full h-full p-0 placeholder-gray-400 bg-transparent border-0 outline-none focus:placeholder-gray-500 focus:ring-0 bg-transparent',
                            'dark:bg-gray-700 dark:placeholder-gray-400' => config('forms.dark_mode'),
                            'cursor-default' => $isDisabled(),
                        ]); ?>"
                    />

                    <span
                        class="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none rtl:right-auto rtl:left-0 rtl:pl-2">
                        <svg class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'w-5 h-5 text-gray-400',
                            'dark:text-gray-400' => config('forms.dark_mode'),
                        ]); ?>" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                        </svg>
                    </span>

                </div>
            </button>

        </div>
    </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\SyGeD\vendor\malzariey\filament-daterangepicker-filter\src\/../resources/views/date-range-picker.blade.php ENDPATH**/ ?>