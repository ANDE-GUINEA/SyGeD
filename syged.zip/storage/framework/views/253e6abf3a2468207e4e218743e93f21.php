<div x-data="{ open: false }" class="px-6 py-4 ">
                <a x-on:click="open = ! open"
                    class="inline-flex items-center px-4 py-2 mb-2 text-sm font-medium text-orange-600 border border-gray-200 rounded-lg shadow cursor-pointer bg-warning dark:bg-gray-900 dark:border-gray-600 dark:text-white">
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24"
                        stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                    </svg>
                    <span class="mr-2 text-xl text-indigo-500 dark:text-white">
                        Documents soumis
                    </span>
                </a>

                <div>
                    <div x-show="open" x-transition>

                        <div class="grid w-full grid-cols-1 gap-6 p-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                            <?php echo $__env->make('components.card-icons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <!-- __BLOCK__ --><?php if($record->autres): ?>
                                <!-- __BLOCK__ --><?php $__empty_1 = true; $__currentLoopData = $record->references; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$dossier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php echo $__env->make('components.references', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?> <!-- __ENDBLOCK__ -->
                            <?php endif; ?> <!-- __ENDBLOCK__ -->
                            <!-- __BLOCK__ --><?php if($record->confidential): ?>
                                <!-- __BLOCK__ --><?php $__empty_1 = true; $__currentLoopData = $record->confidential; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$dossier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php echo $__env->make('components.card-confidentiel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?> <!-- __ENDBLOCK__ -->

                            <?php endif; ?> <!-- __ENDBLOCK__ -->
                            <!-- __BLOCK__ --><?php if($record->autres): ?>
                                <!-- __BLOCK__ --><?php $__empty_1 = true; $__currentLoopData = $record->autres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$dossier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php echo $__env->make('components.card-public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?> <!-- __ENDBLOCK__ -->

                            <?php endif; ?> <!-- __ENDBLOCK__ -->
                        </div>
                    </div>
                </div>
            </div>
<?php /**PATH C:\laragon\www\SyGeD\resources\views/components/soumis/document-soumis.blade.php ENDPATH**/ ?>